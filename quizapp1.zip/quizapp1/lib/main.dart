import 'package:flutter/material.dart';

void main() => runApp(QuizApp());

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "কুইজ অ্যাপ",
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      home: QuizPage(),
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  int _currentQuestionIndex = 0;
  int _score = 0;

  final List<Question> _questions = [
    Question(
      text: 'Which language is used to develop Flutter apps?',
      options: ['Java', 'Dart', 'Kotlin', 'Swift'],
      correctAnswerIndex: 1,
    ),
    Question(
      text: 'What does CPU stand for?',
      options: [
        'Central Process Unit',
        'Central Processing Unit',
        'Computer Personal Unit',
        'Central Peripheral Unit'
      ],
      correctAnswerIndex: 1,
    ),
    Question(
      text: 'Which company developed Android?',
      options: ['Google', 'Apple', 'Microsoft', 'IBM'],
      correctAnswerIndex: 0,
    ),
    Question(
      text: 'HTML is used to?',
      options: ['Style pages', 'Program games', 'Structure web pages', 'Make apps'],
      correctAnswerIndex: 2,
    ),
    Question(
      text: 'Which of these is not a programming language?',
      options: ['Python', 'Ruby', 'HTML', 'Java'],
      correctAnswerIndex: 2,
    ),
  ];

  void _answerQuestion(int selectedIndex) {
    if (selectedIndex == _questions[_currentQuestionIndex].correctAnswerIndex) {
      _score++;
    }
    setState(() {
      _currentQuestionIndex++;
    });
  }

  void _resetQuiz() {
    setState(() {
      _currentQuestionIndex = 0;
      _score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isQuizFinished = _currentQuestionIndex >= _questions.length;

    return Scaffold(
      appBar: AppBar(title: Text('Quiz App')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: isQuizFinished
            ? Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Your score is $_score / ${_questions.length}',
                style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _resetQuiz,
              child: Text('Restart Quiz'),
            ),
          ],
        )
            : Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              _questions[_currentQuestionIndex].text,
              style: TextStyle(fontSize: 20),
            ),
            SizedBox(height: 20),
            ..._questions[_currentQuestionIndex].options.asMap().entries.map(
                  (entry) {
                int idx = entry.key;
                String text = entry.value;
                return ElevatedButton(
                  onPressed: () => _answerQuestion(idx),
                  child: Text(text),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

class Question {
  final String text;
  final List<String> options;
  final int correctAnswerIndex;

  Question({
    required this.text,
    required this.options,
    required this.correctAnswerIndex,
  });
}
